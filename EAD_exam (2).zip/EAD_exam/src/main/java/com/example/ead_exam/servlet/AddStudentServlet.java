package com.example.ead_exam.servlet;


import com.example.ead_exam.Service.StudentService;
import com.example.ead_exam.entity.Student;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/addStudent")
public class AddStudentServlet extends HttpServlet {

    private StudentService studentService = new StudentService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String studentCode = req.getParameter("studentCode");
        String fullName = req.getParameter("fullName");
        String address = req.getParameter("address");

        Student student = new Student();
        student.setStudentCode(studentCode);
        student.setFullName(fullName);
        student.setAddress(address);

        studentService.addStudent(student);
        resp.sendRedirect("students.jsp");
    }
}
