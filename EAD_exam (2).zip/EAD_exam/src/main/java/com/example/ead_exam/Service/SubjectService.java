package com.example.ead_exam.Service;

import com.example.ead_exam.DAO.SubjectDAO;
import com.example.ead_exam.entity.Subject;

import java.util.List;

public class SubjectService {

    private SubjectDAO subjectDAO = new SubjectDAO();

    // Thêm môn học
    public void addSubject(Subject subject) {
        subjectDAO.addSubject(subject);
    }

    // Lấy danh sách tất cả môn học
    public List<Subject> getAllSubjects() {
        return subjectDAO.getAllSubjects();
    }

    // Lấy môn học theo ID
    public Subject getSubjectById(int subjectId) {
        return subjectDAO.getSubjectById(subjectId);
    }
}
