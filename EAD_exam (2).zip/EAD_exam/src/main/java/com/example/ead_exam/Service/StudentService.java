package com.example.ead_exam.Service;


import com.example.ead_exam.DAO.StudentDAO;
import com.example.ead_exam.entity.Student;

import java.util.List;

public class StudentService {

    private StudentDAO studentDAO = new StudentDAO();

    // Thêm sinh viên
    public void addStudent(Student student) {
        studentDAO.addStudent(student);
    }

    // Lấy danh sách tất cả sinh viên
    public List<Student> getAllStudents() {
        return studentDAO.getAllStudents();
    }

    // Lấy sinh viên theo ID
    public Student getStudentById(int studentId) {
        return studentDAO.getStudentById(studentId);
    }
}