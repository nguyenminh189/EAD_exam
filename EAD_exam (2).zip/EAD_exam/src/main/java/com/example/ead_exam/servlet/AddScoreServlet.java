package com.example.ead_exam.servlet;

import com.example.ead_exam.Service.StudentScoreService;
import com.example.ead_exam.entity.StudentScore;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/addScore")
public class AddScoreServlet extends HttpServlet {

    private StudentScoreService studentScoreService = new StudentScoreService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int studentId = Integer.parseInt(req.getParameter("studentId"));
        int subjectId = Integer.parseInt(req.getParameter("subjectId"));
        double score1 = Double.parseDouble(req.getParameter("score1"));
        double score2 = Double.parseDouble(req.getParameter("score2"));

        StudentScore studentScore = new StudentScore();
        studentScore.setStudentId(studentId);
        studentScore.setSubjectId(subjectId);
        studentScore.setScore1(score1);
        studentScore.setScore2(score2);

        studentScoreService.addScore(studentScore);
        resp.sendRedirect("scores.jsp");
    }
}