package com.example.ead_exam.DAO;

import com.example.ead_exam.entity.Student;

import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    private List<Student> students = new ArrayList<>();

    public void addStudent(Student student) {
        students.add(student);
    }

    public List<Student> getAllStudents() {
        return students;
    }

    public Student getStudentById(int studentId) {
        for (Student student : students) {
            if (student.getStudentId() == studentId) {
                return student;
            }
        }
        return null;
    }
}