package com.example.ead_exam.DAO;


import com.example.ead_exam.entity.Subject;

import java.util.ArrayList;
import java.util.List;

public class SubjectDAO {

    private List<Subject> subjects = new ArrayList<>();

    public void addSubject(Subject subject) {
        subjects.add(subject);
    }

    public List<Subject> getAllSubjects() {
        return subjects;
    }

    public Subject getSubjectById(int subjectId) {
        for (Subject subject : subjects) {
            if (subject.getSubjectId() == subjectId) {
                return subject;
            }
        }
        return null;
    }
}