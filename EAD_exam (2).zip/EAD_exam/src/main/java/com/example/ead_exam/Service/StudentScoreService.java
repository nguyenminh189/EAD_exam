package com.example.ead_exam.Service;

import com.example.ead_exam.DAO.StudentScoreDAO;
import com.example.ead_exam.entity.StudentScore;

import java.util.List;

public class StudentScoreService {

    private StudentScoreDAO studentScoreDAO = new StudentScoreDAO();

    public void addScore(StudentScore studentScore) {
        studentScoreDAO.addScore(studentScore);
    }

    public List<StudentScore> getAllScores() {
        return studentScoreDAO.getAllScores();
    }

    public List<StudentScore> getScoresByStudentId(int studentId) {
        return studentScoreDAO.getScoresByStudentId(studentId);
    }

    public String calculateGrade(double score1, double score2) {
        double finalScore = 0.3 * score1 + 0.7 * score2;
        if (finalScore >= 8.0) {
            return "A";
        } else if (finalScore >= 6.0) {
            return "B";
        } else if (finalScore >= 4.0) {
            return "C";
        } else {
            return "F";
        }
    }
}
