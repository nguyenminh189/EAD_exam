package com.example.ead_exam.DAO;

import com.example.ead_exam.entity.StudentScore;

import java.util.ArrayList;
import java.util.List;

public class StudentScoreDAO {

    private List<StudentScore> scores = new ArrayList<>();

    public void addScore(StudentScore studentScore) {
        scores.add(studentScore);
    }

    public List<StudentScore> getAllScores() {
        return scores;
    }

    public List<StudentScore> getScoresByStudentId(int studentId) {
        List<StudentScore> result = new ArrayList<>();
        for (StudentScore score : scores) {
            if (score.getStudent().getStudentId() == studentId) {
                result.add(score);
            }
        }
        return result;
    }
}
